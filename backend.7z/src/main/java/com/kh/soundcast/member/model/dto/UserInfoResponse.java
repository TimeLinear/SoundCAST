package com.kh.soundcast.member.model.dto;

public interface UserInfoResponse {

}
