package com.kh.soundcast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoundCastApplicationTests {

	@Test
	void contextLoads() {
	}

}
